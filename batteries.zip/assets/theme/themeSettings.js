export const themeColor = "#83AB30"

export const login = {
    textColor:'#FFFFFF',
    iconColor:'#FFF',
    inputBorderColor:'#FFF',
}