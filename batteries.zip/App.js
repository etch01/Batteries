import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Navigator from './components/navigation/stackNavigator';
export default class App extends React.Component {
  render() {
    return (
      <Navigator/>
    );
  }
}

