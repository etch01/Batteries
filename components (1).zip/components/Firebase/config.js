export default firebaseConfig = {
    apiKey: "AIzaSyBqGvJtjSDKZpEbxescVDrR-MmjF6UgVaM",
    authDomain: "batteries-5b258.firebaseapp.com",
    databaseURL: "https://batteries-5b258.firebaseio.com",
    projectId: "batteries-5b258",
    storageBucket: "batteries-5b258.appspot.com",
    messagingSenderId: "754661588410",
    appId: "1:754661588410:web:396c1e2a69ed7bbd"
  };